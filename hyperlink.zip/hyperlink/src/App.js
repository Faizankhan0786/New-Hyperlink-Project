import data from "./data.json"
import './App.css';

function App() {
  return (
    <div className="App">
    <tbody>
      <th>Title</th>
      <th>Type</th>
      <th>Description</th>
      <th>Filename</th> 
      <th>Height</th>
      <th>Width</th>
      <th>Price</th>
      <th>Rating</th> 

  {data.map((data, i) => {
    return (
        <tr>
          <td >
          {data.title}
          </td>
          <td >
          {data.type}
          </td> <td >
          {data.description}
          </td> <td >
          {data.filename}
          </td> <td >
          {data.height}
          </td> <td >
          {data.width}
          </td> <td >
          {data.price}
          </td> 
          <td >
          {data.rating}
          </td>
        </tr>
    )  
  })}
</tbody>
    </div>
  );
}

export default App;

